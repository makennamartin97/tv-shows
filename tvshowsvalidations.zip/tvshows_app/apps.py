from django.apps import AppConfig


class TvshowsAppConfig(AppConfig):
    name = 'tvshows_app'
